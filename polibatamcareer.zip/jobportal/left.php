<div style="width:200px; background-color:#CCCCCC; height:248px; float:left; margin:auto;border:1px #CCCCCC solid;">


<table style="width:150px;  height:auto;background-color:#CCCCCC; color:#FFFFFF; border: 0px solid #0066CC; margin-left:40px; margin-top:40px; margin-bottom:40px;">

<tr style="width:200px; height:20px;">
<td><a href="edit_profile.php" style="text-decoration:none; color:#FFFFFF;">Edit Profile</a></td>
</tr>
<tr><td><b><a href="my_order.php" style="text-decoration:none; color:#FFFFFF;">My Order</a></b></td>
</tr>
<tr>
<tr><td><a href="change_pass.php" style="text-decoration:none; color:#FFFFFF;"><b>Change Password</b></a></td></tr>
</tr>
<tr><td><a href="view_cart.php" style="text-decoration:none;color:#FFFFFF; "><b>View Cart</b></a></td>
</tr>
</table>


</div>